@extends('layout.v_template')
@section('content')
<h1> Hello, best! </h1>
@endsection
