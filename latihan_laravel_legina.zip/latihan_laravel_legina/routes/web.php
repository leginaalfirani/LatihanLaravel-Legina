<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\c_home;
use App\Http\Controllers\c_dosen;
use App\Http\Controllers\c_mahasiswa;
use App\Http\Controllers\c_user;
use App\Http\Controllers\c_register;
use App\Http\Controllers\c_login;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('v_home');
});

Route::get('/contact', function () {
    return view('v_contact');
});

Route::get('/about', function () {
    return 'Halaman About';
});

Route::get('/kali', function () {
    return 9*9;
});

Route :: view('/contact','v_contact');

Route :: view('/contact','v_contact',[
    'name' => 'Legina Alfirani',
    'email' => 'leginaalfirani24@gmail.com']);

Route::get('/contact', function () {
    return view('contact',['name' => 'Legina Alfirani','email' => 'leginaalfirani24@gmail.com']);
});

Route :: view('/admin','admin/v_admin');
Route :: view('/admin','admin.v_admin');

Route::get('/mahasiswa/', function ($nama_mahasiswa='Legina') {
    return view('mahasiswa',['nama_mahasiswa'=>$nama_mahasiswa]);
});

Route:: view('/about','v_about', [
    'nama' => 'Mahasiswa A',
    'alamat' => 'Cibogo, Subang'
]);


Route::view('/dosen','v_dosen');
Route::view('/mahasiswa','v_mahasiswa');
Route::view('/about','v_about');
Route::view('/contact','v_contact');

Route::view('/login','v_login');
Route::view('/barang','v_barang');
*/
Route::get('/', function () {
    return view('v_index');
});
Route::view('/admin','admin/v_dashboard');
Route::get('/mahasiswa',[c_mahasiswa::class,'index']);