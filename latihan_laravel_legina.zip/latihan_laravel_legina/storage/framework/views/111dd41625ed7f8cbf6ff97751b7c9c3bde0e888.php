<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa</title>
</head>
<body>
    Nama Mahasiswa : Legina
</body>
</html><?php /**PATH C:\xampp\htdocs\latihan_laravel_legina\resources\views/mahasiswa.blade.php ENDPATH**/ ?>