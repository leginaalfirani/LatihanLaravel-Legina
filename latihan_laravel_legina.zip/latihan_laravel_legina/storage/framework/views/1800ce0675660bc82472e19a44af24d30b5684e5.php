
<?php $__env->startSection('content'); ?>
<h1> Hello, best! </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel_legina\resources\views/v_home.blade.php ENDPATH**/ ?>