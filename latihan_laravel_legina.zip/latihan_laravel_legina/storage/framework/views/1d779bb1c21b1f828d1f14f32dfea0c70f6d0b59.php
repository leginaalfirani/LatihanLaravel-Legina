
<?php $__env->startSection('content'); ?>
<h1> <a class="btn btn-primary" href="/barang" role="button">+ Tambah Data</a>
    <a class="btn btn-primary" href="/barang" role="button">Print Data Barang</a>
    <a class="btn btn-primary" href="/barang" role="button">Keluar Aplikasi</a>

  <table class="table table-dark">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Kode Barang</th>
      <th scope="col">Nama Barang</th>
      <th scope="col">Stok</th>
      <th scope="col">Harga Beli</th>
      <th scope="col">Harga Jual</th>
      <th scope="col">Gambar Produk</th>
      <th scope="col">Action</th>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>BRG01</td>
      <td>Samsung M3Os</td>
      <td>7</td>
      <td>Rp 2.520.000,00</td>
      <td>Rp 2.700.000,00</td>
      <td> <img src="<?php echo e(asset('/gambar/brg1.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>
    <tr>
    <th scope="row">2</th>
      <td>BRG02</td>
      <td>Redmi Note 6</td>
      <td>20</td>
      <td>Rp 2.200.000,00</td>
      <td>Rp 2.500.000,00</td>
      <td> <img src="<?php echo e(asset('gambar/brg2.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>
    <tr>
    <th scope="row">3</th>
      <td>BRG03</td>
      <td>Xiaomi Redmi Note 9 Pro</td>
      <td>11</td>
      <td>Rp 3.200.000,00</td>
      <td>Rp 3.500.000,00</td>
      <td> <img src="<?php echo e(asset('/gambar/brg3.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>
    <tr>
    <th scope="row">4</th>
      <td>BRG04</td>
      <td>Xiaomi Redmi Note8</td>
      <td>10</td>
      <td>Rp 2.600.000,00</td>
      <td>Rp 2.850.000,00</td>
      <td> <img src="<?php echo e(asset('/gambar/brg4.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>
    <tr>
    <th scope="row">5</th>
      <td>BRG05</td>
      <td>Vivo X70 Pro</td>
      <td>5</td>
      <td>Rp 18.000.000,00</td>
      <td>Rp 18.500.000,00</td>
      <td> <img src="<?php echo e(asset('/gambar/brg5.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>
    <tr>
    <th scope="row">6</th>
      <td>BRG06</td>
      <td>Asus Zenphone 7 Pro</td>
      <td>6</td>
      <td>Rp 3.200.000,00</td>
      <td>Rp 3.350.000,00</td>
      <td> <img src="<?php echo e(asset('/gambar/brg6.jpg')); ?>" width="100px">
      <td><a class="btn btn-primary" href="#" role="button">Edit</a></td>
            <td><a class="btn btn-primary" href="#" role="button">Hapus</a></td>
    </tr>

  </tbody>
</table> </h1>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\latihan_laravel_legina\resources\views/v_barang.blade.php ENDPATH**/ ?>