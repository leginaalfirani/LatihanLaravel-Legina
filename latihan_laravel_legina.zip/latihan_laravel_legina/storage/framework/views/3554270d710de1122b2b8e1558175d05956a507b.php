<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact</title>
</head>
<body>
    <h1> Ini adalah halaman Contact </h1>
    <h2> <?php echo e($name); ?></h2> 
    <h2> <?php echo e($email); ?></h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\latihan_laravel_legina\resources\views/contact.blade.php ENDPATH**/ ?>