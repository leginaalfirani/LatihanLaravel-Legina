<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
<h1> Ini adalah halaman About </h1>
    <h2> <?php echo e($nama); ?></h2> 
    <h2> <?php echo e($alamat); ?></h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\latihan_laravel_legina\resources\views/about.blade.php ENDPATH**/ ?>